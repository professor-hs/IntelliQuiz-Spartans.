import os
import uuid
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from utils.pdf_reader import extract_pdf_text_bytes
from utils.quiz_generator import generate_quiz_from_text
from utils.helpers import save_history

app = FastAPI(title="AI Quiz Generator - Backend (Pro)")

# CORS for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

HISTORY_ENABLED = os.getenv("HISTORY_ENABLED", "true").lower() in ("true", "1", "yes")


# ✔ FIXED INDENTATION
class QuizRequest(BaseModel):
    questions: Optional[int] = 10
    difficulty: Optional[str] = "medium"
    q_types: Optional[list] = None


@app.post("/generate_quiz")
async def generate_quiz_api(
    pdf: UploadFile = File(...),
    questions: int = Form(10),
    difficulty: str = Form("medium"),
    q_types: Optional[str] = Form(None),
):
    """
    Endpoint to upload PDF and generate quiz.
    q_types (optional) should be comma-separated like: 'mcq,tf,fill'
    """

    # Read file contents
    content = await pdf.read()
    if not content:
        raise HTTPException(status_code=400, detail="Empty file uploaded")

    # Extract text from PDF
    try:
        text, has_text = extract_pdf_text_bytes(content)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not has_text:
        raise HTTPException(
            status_code=422,
            detail="PDF does not contain extractable text (may be scanned). Upload text PDF."
        )

    # Parse q_types
    if q_types:
        types = [t.strip() for t in q_types.split(",") if t.strip()]
    else:
        types = None

    # Generate quiz using AI
    try:
        quiz_obj = generate_quiz_from_text(
            text,
            total_questions=questions,
            difficulty=difficulty,
            q_types=types
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI generation failed: {e}")

    # Save history entry
    if HISTORY_ENABLED:
        try:
            entry = {
                "id": str(uuid.uuid4()),
                "filename": pdf.filename,
                "questions": questions,
                "difficulty": difficulty,
                "timestamp": datetime.utcnow().isoformat() + "Z",
            }
            save_history(entry)
        except Exception:
            pass

    return {"status": "ok", "data": quiz_obj}


@app.get("/health")
async def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat() + "Z"}
