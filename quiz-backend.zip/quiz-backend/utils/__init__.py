"""
Utility package for AI Quiz Generator.

This file makes the `utils` directory a Python package
and exposes commonly used utility functions.
"""

from .pdf_reader import extract_pdf_text_bytes
from .quiz_generator import generate_quiz_from_text
from .helpers import save_history, chunk_text
