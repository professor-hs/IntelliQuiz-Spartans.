import os
import json
import re
import openai
from typing import List, Dict

from .helpers import chunk_text

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


def call_openai_for_chunk(chunk: str, q_types: List[str], difficulty: str, questions_per_chunk: int) -> List[Dict]:
    """
    Calls the OpenAI API and extracts JSON list of questions.
    """

    openai.api_key = os.getenv("OPENAI_API_KEY")
    if not openai.api_key:
        raise RuntimeError("OPENAI_API_KEY not set in environment")

    prompt = f"""
You are a quiz generator. Create {questions_per_chunk} questions from the text.

Allowed question types: {", ".join(q_types)}
Difficulty: {difficulty}

Return ONLY a JSON array. Example:
[
  {{
    "id": "q1",
    "type": "mcq",
    "question": "What is X?",
    "options": ["A", "B", "C", "D"],
    "answer": "B",
    "explanation": "Because..."
  }}
]

Text:
{chunk}
"""

    response = openai.ChatCompletion.create(
        model=OPENAI_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=1200,
    )

    text_out = response.choices[0].message["content"].strip()

    # -------- FIXED JSON EXTRACTION BLOCK -------- #
    try:
        # Detect JSON array inside text
        match = re.search(r"(\[\s*\{.*?\}\s*\])", text_out, flags=re.DOTALL)
        json_text = match.group(1) if match else text_out

        parsed = json.loads(json_text)
        if isinstance(parsed, list):
            return parsed
        return []
    except Exception:
        return []


def generate_quiz_from_text(full_text: str, total_questions: int = 10, difficulty: str = "medium",
                            q_types: List[str] = None) -> Dict:
    """
    Main function: Splits text into chunks, generates quiz questions & summary.
    """

    if not q_types:
        q_types = ["mcq", "tf", "fill", "short"]

    chunks = chunk_text(full_text, chunk_size=4000, overlap=300)

    if not chunks:
        return {"questions": [], "summary": "", "key_points": []}

    # distribute questions across chunks
    per_chunk = max(1, total_questions // len(chunks))

    questions = []

    # -------- GENERATE QUESTIONS -------- #
    for i, chunk in enumerate(chunks):
        qlist = call_openai_for_chunk(chunk, q_types, difficulty, per_chunk)

        # Assign unique IDs
        for idx, q in enumerate(qlist):
            q["id"] = q.get("id", f"c{i+1}_q{idx+1}")
            questions.append(q)

        if len(questions) >= total_questions:
            break

    # limit to requested count
    questions = questions[:total_questions]

    # -------- SUMMARY AND KEY POINTS -------- #
    summary = ""
    key_points = []

    try:
        openai.api_key = os.getenv("OPENAI_API_KEY")

        summary_prompt = (
            f"Summarize this text in 3 sentences and list 5 key points:\n\n{chunks[0][:3000]}"
        )

        summary_resp = openai.ChatCompletion.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": summary_prompt}],
            temperature=0.2,
            max_tokens=300,
        )

        summary_text = summary_resp.choices[0].message["content"].strip()

        parts = [p.strip() for p in summary_text.split("\n") if p.strip()]

        if parts:
            summary = parts[0]
            key_points = parts[1:6]

    except Exception:
        summary = ""
        key_points = []

    return {
        "questions": questions,
        "summary": summary,
        "key_points": key_points
    }
