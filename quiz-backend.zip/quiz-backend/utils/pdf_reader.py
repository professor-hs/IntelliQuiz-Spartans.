from pypdf import PdfReader
from typing import Tuple
import io


def extract_pdf_text_bytes(pdf_bytes: bytes, max_chars: int = 20000) -> Tuple[str, bool]:
    """
    Extracts text from PDF bytes.
    Returns (text, has_text_bool).

    If text extraction yields very little or empty string,
    has_text_bool will be False → meaning scanned/blank/image-only PDF.
    """
    try:
        reader = PdfReader(io.BytesIO(pdf_bytes))
    except Exception as e:
        raise ValueError(f"Could not read PDF: {e}")

    text = []
    for page in reader.pages:
        ptext = page.extract_text() or ""
        if ptext:
            text.append(ptext)

    joined = "\n\n".join(text).strip()

    if not joined:
        return "", False  # scanned or empty PDF

    # limit size to avoid huge prompts being sent to the LLM
    return joined[:max_chars], True
