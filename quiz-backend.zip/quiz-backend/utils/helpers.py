import json
import os
from datetime import datetime
from typing import List

HISTORY_FILE = os.path.join("history", "logs.json")


def ensure_history_file():
    """Ensure that the history file exists."""
    os.makedirs(os.path.dirname(HISTORY_FILE), exist_ok=True)
    if not os.path.exists(HISTORY_FILE):
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump([], f)


def save_history(entry: dict):
    """Append a history entry to logs.json safely."""
    ensure_history_file()
    with open(HISTORY_FILE, "r+", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            data = []
        data.append(entry)
        f.seek(0)
        json.dump(data, f, ensure_ascii=False, indent=2)


def chunk_text(text: str, chunk_size: int = 3000, overlap: int = 200) -> List[str]:
    """Splits text into overlapping chunks to fit into LLM context."""
    if not text:
        return []

    chunks = []
    start = 0
    length = len(text)

    while start < length:
        end = start + chunk_size
        chunks.append(text[start:end])
        start = end - overlap  # add overlap to maintain continuity

    return chunks
